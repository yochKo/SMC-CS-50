#include<stdio.h>
#include<string.h>


int main() {

	char sentence[50];
	char v;
	int p;

	printf("1. enter the sentence.\n");
	gets(sentence);
	printf("2. enter the character you want count.\n");
	scanf_s("%c", &v);
	p = find(sentence, v);
	if (p == -1) {
		printf("Error! letter is no found\n");
	}
	else {
		printf("%d is number of the character in the sentence.\n", p);
	}
	system("pause");
	return 0;
}

int find(char e[], char k) {
	int c = 0;
	c = strlen(e);
	int count = 0;
	for (int i = 0; i < c; i++) {
		if (e[i] == k) {
			count++;
		}
	}
	if (count == 0) {
		count = -1;
	}
	return count;
}