#include <stdio.h>
int main()
{
	float min_in = 0, max_in = 0, total = 0, val_in = 0, avg = 0;
	int num_count = 0;

	/*
	Before repeat, we need first value for compare.
	when later value come in, first value are used to compare later value is lower or higher.
	*/

	printf("Enter the value.\n");
	scanf_s("%f", &val_in);
	max_in = min_in = val_in;
	total = val_in;
	num_count++;
	
	/*repeat part
	if val_in is 0, the while not end immediately because we check the val_in value when loop starts.
	So, num_count go up for count input and 0 plus to the total. thus, the avg is diffrent from the correct.
	To fix it, i made a check point. if val_in is 0, num_count dont go up(actually, go up and down).
	*/

	while (val_in != 0) {
		
		printf("Enter the value.\n");
		scanf_s("%f", &val_in);
		num_count++;
		total = total + val_in;

		//check the val_in is 0.//

		if (val_in == 0) {
			num_count--;
		}

		//max//

		else if (val_in > max_in) {
			max_in = val_in;
			printf("Max change to %f\n", max_in);
		}
		
		//min//
		
		else if (val_in < min_in && val_in != 0) {
			min_in = val_in;
			printf("Min change to %f\n", min_in);
		}
		printf("total inside the loop is %f\n", total);
	}

	// to check the if function for 0 is work or not.//
	printf("total outside of the loop is %f\n", total);
	printf("count is %d\n", num_count);
	
	printf("***\n");
	//calculate//
	avg = total / num_count;

	//print//
	printf("The minimum entry was          : %5.2f\n", min_in);
	printf("The maximum entry was          : %5.2f\n", max_in);
	printf("The average of all entries was : %5.2f\n", avg);

	getch();
	return 0;
}