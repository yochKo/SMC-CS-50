#include <stdio.h>

int main()
{
	//declare avg, mid, final, total.//
	int asgn1 = 0;
	int asgn2 = 0;
	int asgn3 = 0;
	float avg = 0;
	int mid = 0;
	int fin = 0;
	float total = 0;
	
	//get the assignment score//
	printf("Input the score of first assignments\n");
	scanf("%d", &asgn1);
	printf("Input the score of second assignments\n");
	scanf("%d", &asgn2);
	printf("Input the score of third assignments\n");
	scanf("%d", &asgn3);
	//average of the assignment//
	avg = ((asgn1 + asgn2 + asgn3) / 3);
	//get the test score //
	printf("Input the score of the midterm\n");
	scanf("%d",&mid);
	printf("Input the score of the final exam\n");
	scanf("%d",&fin);
	//calculate the final score//
	total = (avg*0.4) + (mid*0.3) + (fin*0.3);
	//show//
	printf("Your final score is: %f", total);
	//stop//
	getch();

	return 0;
}