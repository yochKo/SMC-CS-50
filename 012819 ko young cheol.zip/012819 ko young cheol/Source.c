#include<stdio.h>


int cal(int array[], int arraysize, float arrayavg);
void func(double a, double b, double *c, double *d);

int main() {
	/*
	1.Write code for a function that receives two parameters (a,and b) by value and has two more parameters (c and d) by reference. 
	All parameters are double. The function works by assigning c to (a/b) and assigning d to (a*b).
	From main, use scanf to get two numbers, then call the function, and then display both returned values to the output in a printf statement.
	*/
	double a = 0, b = 0;
	double c = 0;
	double d = 0;
	printf("1. abcd problem\n");
	printf("enter a and b\n");
	scanf_s("%lf", &a);
	scanf_s("%lf", &b);
	func(a, b, &c, &d);
	printf("a is %8.4lf, b is %8.4lf\n", a, b);
	printf("(a/b) is %8.4lf, (a*b) is %8.4lf\n", c, d);

	/*
	2. After part 1 is completed, write code to get 20 integer numbers from the user. 
	The code then displays how many of those numbers are above the numbers average. 
	To get proper credit you must follow these steps:
	a. write a for loop to fill the array with numbers from the user. Use a pointer
	b. use an index to pass through all array elements to calculate the average in another loop.
	c. write a function, then pass the array, its size, and the average to the function. 
	The function returns the count of the number of elements that are above the average.
	*/
	printf("2. average problem\n");
	int arr[20];
	const int size = 20;
	int *Ptr;
	Ptr = &arr;
	int out = 0, sum = 0;
	float avg=0;
	for (int i = 0; i < size; i++) {
		scanf_s("%d", Ptr);
		Ptr++;
	}
	for (int i = 0; i < size; i++) {
		sum += arr[i];
	}
	avg = (sum / size);
	out = cal(arr, size, avg);
	printf("%12.2f is the average of elements\n", avg);
	printf("%d is the number of elements that are above the average\n", out);


	system("pause");
	return 0;
}

void func(double a, double b, double *c, double *d) {
	*c = (a / b);
	*d = (a)*(b);	
}

int cal(int array[], int arraysize, float arrayavg) {
	int count = 0;
	for (int i = 0; i < arraysize; i++) {
		if (array[i] > arrayavg) {
			count++;
		}
	}
	return count;
}