/*Code for bank

while i is 1, loop keep going.

1. printmenu
	print menu repeatly.

2. -1 show balance
   -2 deposit
   -3 withdrawal
   -4 quit  
   -default 

3. fuction
*/

#include<stdio.h>
//declation
void printmenu();
float deposit(float n, float m);
float withdrawal(float j, float k);

//main
int main() {
	int menu=0;
	float balance = 100, amount = 0, value = 0;
	char ch = ' ';
	while (menu!=4) {
		printmenu();
		scanf_s("%d", &menu);
		printf("------------------\n");
		switch (menu) {
		case 1:
			printf("Current balance is %12.2f\n", balance);
			break;
		case 2:
			printf("please enter the amount of deposit : ");
			scanf_s("%f", &amount);
			value = deposit(balance, amount);
			if (value == -1) {
				printf("Error!(You can only enter the number between 0 to 10000.00.)\n");
			}
			else {
				balance = value;
			}
			break;
		case 3:
			printf("please enter the amount of withdrawal : ");
			scanf_s("%f", &amount);
			value = withdrawal(balance, amount);
			if (value == -1) {
				printf("Error!(You can't enter less or equal 0)\n");
			}
			else if (value == -2) {
				printf("Error!(The balance can't not be less than 10)\n");
			}
			else {
				balance = value;
			}
			break;
		case 4:
			printf("Thank you for using!.\n");
			break;
		default:
			printf("Error! (enter the number between 1-4)\n");
			system("pause");
			break;
		}
	}	
	system("pause");
	return 0;
}
//fuction
void printmenu() {
	printf("/////////////////////////////\n");
	printf("Enter the menu number\n");
	printf("#1 : show the current balance\n");
	printf("#2 : Deposit\n");
	printf("#3 : Withdrawl\n");
	printf("#4 : Quit\n");
	printf("/////////////////////////////\n");
}

float deposit(float n, float m) {
	if (m>=10000.00||m<=0) {
		return -1;
	}
	else {
		n = (n + m);
		return n;
	}
}

float withdrawal(float j, float k) {
	if (k <= 0) {
		return -1;
	}
	if ((j - k) < 10) {
		return -2;
	}
	else {
		j = (j - k);
		return j;
	}
}
